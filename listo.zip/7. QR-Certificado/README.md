# QR-Certificado

Permite generar a partir de una plantilla de word exportada en Html un codigo QR incrustado en la Html, para asi poder imprimir y generar algun reporte rapidamente

# Libreria QR

https://github.com/davidshimjs/qrcodejs

# Demo

https://olanaso.github.io/QR-Certificado/
